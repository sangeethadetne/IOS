//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func oneFun(one : Int, outerTwo two : String,_ third : Double)->(Int,String){
    let combine = one + Int(third)
    let result = two + two
    return (combine,result)
}
print(oneFun(one: 12, outerTwo: "one", 2.5))
var (x,y) = oneFun(one: 6, outerTwo : "x", 7.3)
print(x,y)


var s1 : String = "hello"
var s2 = s1
s1.append ("v")//in s1 the changes ar emade they are not affected to s2
print(s1)
print(s2)


struct Rectangle{
    var height : Int=10
    var width : Int=20;
    var area : Int{
        get{
            return height * width
        }
        set{
            width = newValue/height
        }
    }
    mutating func doubleHeight(){
    height=height*2
    }
}
var r1=Rectangle()
print(r1)
print(r1.area)

r1.height=5
print(r1.area)

r1.area=999
print(r1.area)

r1.area=1000
print(r1.area)



class Size{
    private var _size : Int
    
    init(size : Int){
        if size < 0{
        _size=0
        }
        else{
            _size=size
            
        }
        
    }
    var size : Int {
        get{
            return _size
        }
        set{
        if newValue < 0{
        _size = 0
        }
        else{
            _size=newValue
            }
        }
    }
}
var s : Size=Size(size: -3)
print(s.size)
s.size=50
print(s.size)




