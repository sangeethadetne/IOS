//
//  Model.swift
//  CoinOp
//
//  Created by iOS on 2/8/18.
//  Copyright © 2018 Charles Hoot. All rights reserved.
//

import Foundation

class CoinAppMachine{
    var moneyCount : Double = 0.0
    static let COST : Double = 2.50
    func deposit(amount : Double){
        moneyCount += amount
    }
    func purchase() -> Bool{
        if self.moneyCount > CoinAppMachine.COST {
            moneyCount -= CoinAppMachine.COST
            return  true
        }
        return false
    }
}
