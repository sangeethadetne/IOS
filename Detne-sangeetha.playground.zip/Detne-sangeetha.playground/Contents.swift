//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var x = 2,y = 3,z = 4
let first = true    //it is bool value
let second = "Something" //second is of type String
let third = 12.48   // the third is of type double

print(x,y,z, separator: "#", terminator: "**\n")
print(first,second,third, separator: "#",terminator: "**\n")

/*
 Average of the x,y,z
 */
var average:Double
average = (Double)(x + y + z) / 3

/*
 Sorting of the array
 */

var data1:[Int] = [19,1,22,3,1,7,17,18,31]
data1.sort()
print(data1)
/*
  loops on array
 */
var data2:[Int] = []
for index in stride ( from:100, to:1000,by:2)
{
    data2.append(index)
}
data2.insert(111, at: 0)
data2.insert(11001, at: 1)
print(data2.count)

/*
 sum of the numbers that are divisible by 3
 */
var sum=0
for value in data2{
    if value%3==0
    {
        sum+=value
    }
}
print("The sum of the numbers divisible by 3 are \(sum)")

var data3:[Int]=[]
for _ in 1..<20{
    data3.append((Int)(arc4random_uniform(20)))
    }
print(data3)


for i in data3{
    switch i{
    case 1,2,3,7 : print("Beetle")
    case 10 ... 18 : print("Butterfly")
    case 8,20 : print("Moth")
    default: print("Wasp")
        
    }
}


var data4:[Int]=[23,1,2,3,4,7,13,22,2,23,4]
for value in data4{
    let x=value%2
   let y=0
    if x==y
    {
    if let index=data4.index(of: value){
        data4.remove(at: index)
    }
    }
}
print(data4)

var data5:[String]=[]
data5+=["teja","jyothi"]
data5.append("sangeetha")
data5.insert("All about me", at: 0)
print(data5)

let sinus=(3.14)/2
print("The sine value of pie/2 is \(sin((sinus)))")
print("The sine value of 3pie/2 is \(sin(270*(sinus)*3))")
print("The sine value of 2pie/2 is \(sin(180*(sinus)*2))")

print("The cosine value of pie/2 is \(cos((sinus)))")
print("The cosine value of 3pie/2 is \(cos(270*(sinus)*3))")
print("The cosine value of 2pie/2 is \(cos(180*(sinus)*2))")

for value in 1 ... 1000{
//ar x= sine
}
