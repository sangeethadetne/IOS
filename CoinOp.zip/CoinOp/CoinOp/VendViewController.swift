//
//  VendViewController.swift
//  CoinOp
//
//  Created by iOS on 2/8/18.
//  Copyright © 2018 Charles Hoot. All rights reserved.
//

import UIKit

class VendViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var amountLBL: UILabel!
    override func viewWillAppear(_ animated: Bool) {
        let amount : Double = AppDelegate.myModel.moneyCount
        amountLBL.text = "Total amount is \(amount)"
    }
    
    @IBAction func vendAction(_ sender: UIButton) {
        let success = AppDelegate.myModel.purchase()
        let amount = AppDelegate.myModel.moneyCount
        if success {
            amountLBL.text = "Drink!  You have \(amount) left"
        }
        else {
            amountLBL.text = "No Drink. You only have \(amount) left"

        }
    }
    
    
    


}
